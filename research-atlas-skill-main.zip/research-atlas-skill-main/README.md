# 科研全景图谱技能（Research Atlas Skill）

`research-atlas-v2-1` 是一项面向高召回率科研与技术情报检索的 Codex 技能。它把一个研究问题转化为可复现的“研究全景图谱 + 创新与机会图谱”，覆盖论文、综述、预印本、代码、模型、数据集、作者、实验室、基金、专利、项目、临床试验、企业与可信新闻等多类证据。

![Research Atlas 工作流](assets/research-atlas-workflow.png)

## 核心能力

- 先构建概念格与同义词族，再执行多查询族、多来源高召回检索。
- 合并 DOI、题名、作者和项目版本，避免重复计算预印本与正式发表版本。
- 将主题相关性与证据成熟度、影响力和机构声誉分开评估。
- 对强、中、弱相关工作分级，并为跨主题研究计算独立的桥接分数。
- 从强相关种子执行参考文献、被引、相似工作、作者与实验室扩展。
- 检索代码、模型、数据集、基金、专利、临床试验和产业项目。
- 以搜索覆盖矩阵和饱和度门槛约束“全面”“空白”与“创新性”结论。

## 默认工作流

研究问题 → 概念扩展 → 多来源召回 → 去重与版本合并 → 相关性评估 → 强种子集 → 引用与实体滚雪球 → 作者/实验室扩展 → 代码/模型/数据集 → 专利/基金/项目 → 饱和度检查 → 研究全景图谱 → 创新与机会图谱。

基本原则是：**先保证召回率，再提高精确率**。

## 仓库结构

```text
research-atlas-skill/
├── README.md
├── LICENSE
├── assets/
│   └── research-atlas-workflow.png
├── dist/
│   └── research-atlas-v2-1.zip
└── research-atlas-v2-1/
    ├── SKILL.md
    ├── manifest.txt
    ├── examples/
    ├── resources/
    └── templates/
```

## 安装

在 Codex 中使用 `skill-installer`，从以下地址安装：

```text
https://github.com/Zhang-project/research-atlas-skill/tree/main/research-atlas-v2-1
```

也可以下载 [`dist/research-atlas-v2-1.zip`](dist/research-atlas-v2-1.zip)，将其中的 `research-atlas-v2-1` 文件夹复制到：

```text
$CODEX_HOME/skills/
```

如果未设置 `CODEX_HOME`，默认位置通常是 `~/.codex/skills/`。

## 使用示例

```text
使用 $research-atlas-v2-1，系统检索“大模型 × 病理归因 × 脑解码”的研究全景；分别评估三个主题轨道及其交叉桥接证据，给出关键实验室、公开模型/代码/数据、基金与专利，并明确搜索覆盖和饱和度状态。
```

## 主要输出

1. 研究问题解释与概念分支
2. 检索覆盖、日期、查询族和来源矩阵
3. 强/中/弱相关工作及证据成熟度
4. 关键实验室、团队和在研项目
5. 代码、模型、数据集、基金、专利和临床试验
6. 引用网络、研究空白与创新/机会图谱
7. 搜索日志、剩余缺口和饱和度结论

## 证据与隐私边界

- “未检索到”不等于“不存在”；创新性表述必须与搜索覆盖和饱和度证据相匹配。
- 新闻、企业页面、代码和预印本不能替代同行评议证据，报告必须保留证据类型。
- 本仓库仅包含公开的技能说明、模板、示例和工作流图片，不包含用户稿件、未公开数据、检索凭据或本地工作记录。
- 使用本技能时，不要把密码、访问令牌、私有数据或受限全文提交到公开仓库。

## 许可证

本项目采用 [MIT License](LICENSE)。

---

# Research Atlas Skill

`research-atlas-v2-1` is a Codex skill for high-recall scientific and technology intelligence. It converts a research question into a reproducible **Research Landscape + Novelty/Opportunity Map** across papers, reviews, preprints, code, models, datasets, authors, laboratories, grants, patents, projects, clinical trials, companies, and reputable news.

## Core capabilities

- Build a concept lattice and synonym families before running multi-query, multi-source recall.
- Merge DOI, title, author, and project versions so preprints and published versions are not double counted.
- Score topical relevance separately from evidence maturity, impact, and institutional prestige.
- Grade strong, medium, and weak work, with an independent bridge score for multi-track questions.
- Expand strong seeds through references, citations, related work, authors, and laboratories.
- Search code, models, datasets, grants, patents, clinical trials, and translational projects.
- Constrain completeness, gap, and novelty claims with a source-coverage matrix and saturation gate.

## Default workflow

Research Question → Concept Expansion → Multi-source Recall → Deduplication and Version Resolution → Relevance Engine → Strong Seed Set → Citation and Entity Snowball → Author/Lab Expansion → Code/Model/Dataset → Patent/Grant/Project → Saturation Check → Research Landscape → Novelty/Opportunity Map.

The governing principle is: **recall first, precision later**.

## Repository structure

```text
research-atlas-skill/
├── README.md
├── LICENSE
├── assets/
│   └── research-atlas-workflow.png
├── dist/
│   └── research-atlas-v2-1.zip
└── research-atlas-v2-1/
    ├── SKILL.md
    ├── manifest.txt
    ├── examples/
    ├── resources/
    └── templates/
```

## Installation

In Codex, use `skill-installer` with this skill URL:

```text
https://github.com/Zhang-project/research-atlas-skill/tree/main/research-atlas-v2-1
```

Alternatively, download [`dist/research-atlas-v2-1.zip`](dist/research-atlas-v2-1.zip) and copy the enclosed `research-atlas-v2-1` folder into:

```text
$CODEX_HOME/skills/
```

If `CODEX_HOME` is unset, the default location is usually `~/.codex/skills/`.

## Example

```text
Use $research-atlas-v2-1 to map the landscape of “Large Models × Pathology Attribution × Brain Decoding.” Evaluate the three tracks and their bridge evidence separately; identify key laboratories, public models/code/data, grants, and patents; and report search coverage and saturation status.
```

## Main outputs

1. Target interpretation and concept branches
2. Search coverage, dates, query families, and source matrix
3. Strong/medium/weak work with evidence-maturity tags
4. Key laboratories, teams, and active projects
5. Code, models, datasets, grants, patents, and clinical trials
6. Citation-network findings, research gaps, and a novelty/opportunity map
7. Search log, remaining gaps, and saturation conclusion

## Evidence and privacy boundaries

- “Not found” does not mean “does not exist”; novelty language must match search coverage and saturation evidence.
- News, company pages, code, and preprints do not replace peer-reviewed evidence; reports must preserve evidence type.
- This repository contains only public skill instructions, templates, examples, and the workflow image. It contains no user manuscripts, unpublished data, search credentials, or local working records.
- Do not commit passwords, access tokens, private data, or restricted full text to a public repository when using this skill.

## License

This project is licensed under the [MIT License](LICENSE).
