# Example target
Large Models × Pathology Attribution × Brain Decoding

Search as separate tracks:
1. M×P — foundation/large models for disease diagnosis, biomarker/pathophysiology attribution, neural target discovery.
2. M×D — LLM/foundation models for semantic, language, state, image and clinical brain decoding.
3. M×P×D — models that both decode brain states/content and identify disease-related or mechanistic neural representations.
4. Histopathology branch — pathology VLM/LLM as an adjacent methodology source, not automatically a brain-decoding result.

Strong bridge examples should connect at least two of: brain-signal representation, disease/pathology, decoding/generative output, language alignment.
