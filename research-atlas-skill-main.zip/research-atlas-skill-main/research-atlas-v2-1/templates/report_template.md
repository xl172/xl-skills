# Research Atlas Report

## 1. Bottom line

## 2. Target interpretation and concept branches

## 3. Search coverage
- Search date:
- Years:
- Academic sources:
- Engineering/project sources:
- Query families:
- Snowball rounds:
- Saturation status:

## 4. Strong-relevance works
| Work | Year/type | R | Bridge B | Modality | Model | Task | Main evidence | Code/data/project |
|---|---:|---:|---:|---|---|---|---|---|

## 5. Strong clusters

## 6. Medium-relevance map

## 7. Weak-relevance map

## 8. Reviews / field maps

## 9. Key laboratories / teams
| Lab/PI | Institution | L | Role | Strong works | Current signals | Public artifacts |
|---|---|---:|---|---|---|---|

## 10. Code / models / datasets

## 11. Grants / patents / trials / projects / companies

## 12. Citation-network findings

## 13. Research gaps

## 14. Novelty / Opportunity Map
- Established:
- Emerging:
- Open/underexplored:

## 15. Search log and remaining gaps
