# Key Laboratory / Team Intelligence

| Lab/team | PI/senior | Institution | Lab Score L | Role | Strong works | Modalities/tasks | Public artifacts | Active project signal | Why it matters |
|---|---|---|---:|---|---|---|---|---|---|

Roles: Direct competitor / Method source / Adjacent leader / Emerging team.
