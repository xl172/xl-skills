# Source coverage matrix

Mark each family: searched / unavailable / not relevant / pending.

| Layer | Source family | Status | Query families | New strong works | Notes |
|---|---|---|---|---:|---|
| Academic | PubMed/PMC/Europe PMC | | | | |
| Academic | Scholar/WoS/Scopus | | | | |
| Academic | Semantic Scholar/OpenAlex/Crossref | | | | |
| Preprint | arXiv/bioRxiv/medRxiv/OpenReview | | | | |
| Venue | Conferences/journals | | | | |
| Artifact | GitHub/Hugging Face/project pages | | | | |
| Data | OpenNeuro/PhysioNet/etc. | | | | |
| Lab | PI/lab/institution pages | | | | |
| Funding | NIH/NSF/CORDIS/UKB/etc. | | | | |
| IP | Patents/Lens/EPO/Google Patents | | | | |
| Translation | ClinicalTrials/companies/startups | | | | |
| Frontier | Reputable news/technical announcements | | | | |

## Multi-track bridge audit

| Bucket | Count | Strong examples | Interpretation |
|---|---:|---|---|
| Exact A×B×C | | | |
| A×B | | | |
| A×C | | | |
| B×C | | | |
| A only | | | |
| B only | | | |
| C only | | | |
