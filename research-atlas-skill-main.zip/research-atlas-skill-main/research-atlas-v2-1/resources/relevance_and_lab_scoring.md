# Scoring reference

## Work relevance R = 100
- Problem overlap 30
- Task/output overlap 20
- Modality/data overlap 20
- Model/method overlap 20
- Direct target linkage 10

Strong >=75; Medium 50–74; Weak 25–49; Exclude <25.

## Bridge score B = 100
For multi-track questions, score whether one work substantively joins the requested tracks:
- Track A direct contribution 30
- Track B direct contribution 30
- Shared representation/mechanism 20
- Single experiment/model connects both tracks 20

## Lab score L = 100
- Strong-relevance works 30
- Multi-year continuity 20
- Unique data/model/infrastructure 15
- Public artifact ecosystem 15
- Active/current funded pipeline 10
- Exact bridge relevance 10

Lab labels:
- Direct competitor
- Method source
- Adjacent leader
- Emerging team
